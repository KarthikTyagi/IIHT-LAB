package com.nttdata.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ApplicationContext context= new ClassPathXmlApplicationContext("beans.xml");
		System.out.println("beans loaded");
		Student stu=context.getBean("student",Student.class);
		stu.studentmethod();
		SecondStudent ss=context.getBean("SecondStudent",SecondStudent.class);
        ss.studentmethod2();
		
	}

}
