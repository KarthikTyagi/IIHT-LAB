package com.nttdata.spring;

public class Mathcheat {

	public void cheating()

	{
		System.out.println("this is your mathcheat method");

	}
	

	public void cheating2()

	{
		System.out.println("this is your mathcheat method for another student");

	}
	
}
