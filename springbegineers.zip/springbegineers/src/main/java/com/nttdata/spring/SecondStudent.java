package com.nttdata.spring;

public class SecondStudent {

	
private Mathcheat mathcheat;

public void setMathcheat2(Mathcheat mathcheat2) {
	this.mathcheat = mathcheat;
}

public void studentmethod2()
{	
 mathcheat.cheating2();
}

}
