package com.nttdata.spring;

public class Student {

	int id;
	Mathcheat mathcheat;
	public void setId(int id) {
		this.id = id;
	}
	public void setMathcheat(Mathcheat mathcheat) {
		this.mathcheat = mathcheat;
	}
	
	public void studentmethod()
	{
		mathcheat.cheating();
	   System.out.println("my id is"+id);
	}
	
}
